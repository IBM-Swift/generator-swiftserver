// swift-tools-version:4.0
import PackageDescription

let package = Package(
    name: "todo",
    dependencies: [ 
      .package(url: "https://github.com/IBM-Swift/Kitura.git", .upToNextMajor(from: "1.0")),
    ],
)
