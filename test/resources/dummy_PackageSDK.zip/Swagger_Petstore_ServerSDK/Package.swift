// swift-tools-version:4.0
import PackageDescription

let package = Package(
    name: "todo",
    dependencies: [ 
      .Package(url: "https://github.com/IBM-Swift/Kitura.git", majorVersion: 1),
    ],
)
